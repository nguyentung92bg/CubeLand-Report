using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyCompany("Unity Technologies")]
[assembly: InternalsVisibleTo("Unity.Addressables.Editor.BuildReportVisualizer")]
[assembly: InternalsVisibleTo("Unity.Addressables.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.Addressables.Runtime.Tests")]
[assembly: InternalsVisibleTo("PerformanceTests.Editor")]
[assembly: InternalsVisibleTo("Unity.Localization.Editor")]
[assembly: InternalsVisibleTo("Unity.Addressables.Android.Editor")]
